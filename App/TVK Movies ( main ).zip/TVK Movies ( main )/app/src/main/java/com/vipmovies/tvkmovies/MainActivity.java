package com.vipmovies.tvkmovies;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.view.View;
import android.widget.ProgressBar;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.SplashScreen;

import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings;

import java.util.HashMap;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    // ---------------- ADS CONTROL ----------------
    private int adsShownThisSession = 0;           // counts ads per session
    private long lastAdTimeMillis = 0;            // last ad show timestamp

    // Remote Config dynamic values
    private int MAX_ADS_PER_SESSION = 999999;          // default max ads
    private int AD_COOLDOWN_SECONDS = 0;        // default cooldown 3 minutes

    private WebView webView;
    private ProgressBar progressBar;
    private RewardedAd rewardedAd;
    private FirebaseRemoteConfig remoteConfig;

    private String nextUrl = "";

    private static final String DEFAULT_MAIN_URL = "https://vipmovies2.pages.dev/";
    private static final String OFFLINE_URL = "file:///android_asset/offline.html";
    private static final String DEFAULT_REWARD_AD_ID = "ca-app-pub-5583553174133868/4128258678";

    private String MAIN_URL = DEFAULT_MAIN_URL;
    private String REWARD_AD_ID = DEFAULT_REWARD_AD_ID;
    private boolean ADS_ENABLED = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        setContentView(R.layout.activity_main);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.TRANSPARENT);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                WebView.startSafeBrowsing(this, value -> {
                    // Safe browsing initialized
                });
            }

        SplashScreen.installSplashScreen(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);
        progressBar = findViewById(R.id.progressBar);

        MobileAds.initialize(this);
        loadRewardAd();

        // 🔔 ANDROID 13+ NOTIFICATION PERMISSION (SAFE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {

                webView.postDelayed(() -> requestPermissions(
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        101
                ), 1000);
            }
        }

        // ---------------- WEBVIEW SETTINGS ----------------
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);
        settings.setSupportMultipleWindows(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.setBackgroundColor(Color.WHITE);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        // ---------------- WEBVIEW CLIENT ----------------
        webView.setWebViewClient(new WebViewClient() {

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                progressBar.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {

                Uri uri = request.getUrl();

                // 1️⃣ Retry URL for offline
                if (uri.toString().equals("app://retry")) {
                    if (isNetworkAvailable()) {
                        view.loadUrl(MAIN_URL);
                    }
                    return true;
                }

                // 2️⃣ Check network offline
                if (!isNetworkAvailable()) {
                    view.loadUrl(OFFLINE_URL);
                    return true;
                }

                // 3️⃣ Check for reward param
                String rewardUrl = uri.getQueryParameter("reward");

                if (rewardUrl != null) {
                    String fullRewardUrl;

                    // 3a️⃣ Absolute URL
                    if (rewardUrl.startsWith("http")) {
                        fullRewardUrl = rewardUrl;
                    }

                    // 3b️⃣ Relative URL (starts with /)
                    else if (rewardUrl.startsWith("/")) {
                        fullRewardUrl = MAIN_URL + "watch?id=" +  rewardUrl.substring(1); // combine with MAIN_URL
                    }
                    // 3c️⃣ Relative URL (no /)
                    else {
                        // FIX: convert reward id to watch page
                        fullRewardUrl = MAIN_URL + "watch?id=" + rewardUrl;
                    }

                    nextUrl = fullRewardUrl;
                    showRewardAd(); // trigger ad before loading
                    return true;
                }

                // 4️⃣ Open video files externally
                String url = uri.toString().toLowerCase();
                if (url.endsWith(".mp4")) {
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setDataAndType(uri, "video/*");
                    startActivity(intent);
                    return true;
                }

                // 5️⃣ Default: let WebView handle
                return false;
            }

            @Override
            public void onReceivedError(WebView view,
                                        WebResourceRequest request,
                                        WebResourceError error) {
                if (!isNetworkAvailable()) {
                    view.loadUrl(OFFLINE_URL);
                }
            }
        });

        // ---------------- WEB CHROME CLIENT ----------------
        webView.setWebChromeClient(new WebChromeClient() {

            @Override
            public boolean onCreateWindow(WebView view,
                                          boolean isDialog,
                                          boolean isUserGesture,
                                          Message resultMsg) {

                WebView newWebView = new WebView(MainActivity.this);
                newWebView.getSettings().setJavaScriptEnabled(true);

                newWebView.setWebViewClient(new WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(
                            WebView view, WebResourceRequest request) {
                        startActivity(
                                new Intent(Intent.ACTION_VIEW, request.getUrl()));
                        return true;
                    }
                });

                WebView.WebViewTransport transport =
                        (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(newWebView);
                resultMsg.sendToTarget();
                return true;
            }
        });

        // ---------------- BACK BUTTON ----------------
        getOnBackPressedDispatcher().addCallback(this,
                new OnBackPressedCallback(true) {
                    @Override
                    public void handleOnBackPressed() {
                        if (webView.canGoBack()) {
                            webView.goBack();
                        } else {
                            finish();
                        }
                    }
                });

        initRemoteConfig();

        // 🔔 HANDLE NOTIFICATION CLICK (COLD START)
        handleNotificationIntent(getIntent());
    }

    // 🔔 HANDLE NOTIFICATION CLICK (APP RUNNING)
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleNotificationIntent(intent);
    }

    private void handleNotificationIntent(Intent intent) {

        if (intent == null) return;

        String path = intent.getStringExtra("path");
        if (path == null || path.trim().isEmpty()) return;

        String lowerPath = path.toLowerCase();

        // 🔒 Block dangerous patterns
        if (lowerPath.contains("..") ||
                lowerPath.contains("://") ||
                lowerPath.contains("javascript") ||
                lowerPath.contains("file:") ||
                lowerPath.contains("intent:")) {
            return;
        }

        // 🔥 Allow only specific routes
        if (path.equals("/") ||                   // Home
                path.startsWith("/movie/") ||     // Movie page
                path.startsWith("/category/") ||  // Category page
                path.startsWith("/search/") ||    // Search page
                path.startsWith("/list/")) {      // List page

            String safeUrl = MAIN_URL + path;
            webView.loadUrl(safeUrl);
        }
    }

    // ---------------- FIREBASE REMOTE CONFIG ----------------
    private void initRemoteConfig() {

        remoteConfig = FirebaseRemoteConfig.getInstance();

        FirebaseRemoteConfigSettings settings =
                new FirebaseRemoteConfigSettings.Builder()
                        .setMinimumFetchIntervalInSeconds(3600) // 1 Hour update
                        .build();

        remoteConfig.setConfigSettingsAsync(settings);  // ⭐ MISSING LINE

        HashMap<String, Object> defaults = new HashMap<>();
        defaults.put("APP_VERSION",4);
        defaults.put("FORCE_UPDATE", true);
        defaults.put("UPDATE_URL", "https://play.google.com/store/apps/details?id=com.vipmovies.tvkmovies&pcampaignid=web_share");
        defaults.put("MAIN_URL", DEFAULT_MAIN_URL);
        defaults.put("REWARD_AD_ID", DEFAULT_REWARD_AD_ID);
        defaults.put("ADS_ENABLED", true);
        defaults.put("MAX_ADS_PER_SESSION", 999999);          // Firebase configurable
        defaults.put("AD_COOLDOWN_SECONDS", 0);       // Firebase configurable

        remoteConfig.setDefaultsAsync(defaults);

        remoteConfig.fetchAndActivate()
                .addOnCompleteListener(task -> {

                    if (task.isSuccessful()) {

                        MAIN_URL = remoteConfig.getString("MAIN_URL");
                        REWARD_AD_ID = remoteConfig.getString("REWARD_AD_ID");
                        ADS_ENABLED = remoteConfig.getBoolean("ADS_ENABLED");

                        MAX_ADS_PER_SESSION = (int) remoteConfig.getLong("MAX_ADS_PER_SESSION");
                        AD_COOLDOWN_SECONDS = (int) remoteConfig.getLong("AD_COOLDOWN_SECONDS");

                        // ⭐ FORCE UPDATE CHECK
                        ForceUpdateManager.checkUpdate(this, remoteConfig);
                    }

                    loadPage();
                    loadRewardAd();
                });
    }

    private void loadPage() {
        if (isNetworkAvailable()) {
            webView.loadUrl(MAIN_URL);
        } else {
            webView.loadUrl(OFFLINE_URL);
        }
    }

    // ✅ ANDROID 36 SAFE NETWORK CHECK
    private boolean isNetworkAvailable() {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Network network = cm.getActiveNetwork();
            if (network == null) return false;

            NetworkCapabilities caps = cm.getNetworkCapabilities(network);
            return caps != null &&
                    (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                            || caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR));
        } else {
            NetworkInfo info = cm.getActiveNetworkInfo();
            return info != null && info.isConnected();
        }
    }

    private String buildFullUrl(String url) {
        if (url == null) return MAIN_URL;
        if (url.startsWith("http")) return url;
        if (url.startsWith("/")) return MAIN_URL + url.substring(1);
        return MAIN_URL + url;
    }

    // ---------------- ADS ----------------
    private void loadRewardAd() {

        if (!ADS_ENABLED) {
            rewardedAd = null;
            return;
        }

        RewardedAd.load(
                this,
                REWARD_AD_ID,
                new AdRequest.Builder().build(),
                new RewardedAdLoadCallback() {

                    @Override
                    public void onAdLoaded(RewardedAd ad) {
                        rewardedAd = ad;
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError error) {
                        rewardedAd = null;
                    }
                }
        );
    }

    private void showRewardAd() {
        final String finalUrl = buildFullUrl(nextUrl);

        long now = System.currentTimeMillis();

        // 1️⃣ Check session limit
        if (adsShownThisSession >= MAX_ADS_PER_SESSION) {
            webView.loadUrl(finalUrl); // load directly, skip ad
            return;
        }

        // 2️⃣ Check cooldown
        long cooldownMillis = AD_COOLDOWN_SECONDS <= 0
                ? 0
                : AD_COOLDOWN_SECONDS * 1000L;

        if ((now - lastAdTimeMillis) < cooldownMillis) {
            webView.loadUrl(finalUrl);
            return;
        }

        // 3️⃣ Show ad if available
        if (rewardedAd != null && ADS_ENABLED) {

            rewardedAd.setFullScreenContentCallback(
                    new FullScreenContentCallback() {
                        @Override
                        public void onAdDismissedFullScreenContent() {
                            webView.loadUrl(finalUrl);
                            loadRewardAd(); // preload next ad
                            adsShownThisSession++;    // increment session counter
                            lastAdTimeMillis = System.currentTimeMillis(); // set cooldown
                        }

                        @Override
                        public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError adError) {
                            webView.loadUrl(finalUrl);
                            loadRewardAd();
                            adsShownThisSession++;
                            lastAdTimeMillis = System.currentTimeMillis();
                        }
                    });

            rewardedAd.show(this, rewardItem -> {});

        } else {
            webView.loadUrl(finalUrl);
            loadRewardAd();
            adsShownThisSession++;
            lastAdTimeMillis = System.currentTimeMillis();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (isNetworkAvailable()) {
            String currentUrl = webView.getUrl();
            if (currentUrl != null &&
                    currentUrl.startsWith("file:///android_asset/offline.html")) {
                webView.loadUrl(MAIN_URL);
            }
        }
    }
}