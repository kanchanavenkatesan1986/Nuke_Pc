package com.vipmovies.tvkmovies;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;

import androidx.appcompat.app.AlertDialog;

import com.google.firebase.remoteconfig.FirebaseRemoteConfig;

public class ForceUpdateManager {

    public static void checkUpdate(Activity activity, FirebaseRemoteConfig remoteConfig) {

        int remoteVersion = (int) remoteConfig.getLong("APP_VERSION");
        boolean forceUpdate = remoteConfig.getBoolean("FORCE_UPDATE");
        String updateUrl = remoteConfig.getString("UPDATE_URL");

        int currentVersion = getAppVersion(activity);

        if (forceUpdate && remoteVersion > currentVersion) {
            showUpdateDialog(activity, updateUrl);
        }
    }

    private static int getAppVersion(Activity activity) {

        try {
            return activity.getPackageManager()
                    .getPackageInfo(activity.getPackageName(), 0)
                    .versionCode;
        } catch (Exception e) {
            return 1;
        }
    }

    private static void showUpdateDialog(Activity activity, String url) {

        new AlertDialog.Builder(activity)
                .setTitle("Update Required")
                .setMessage("New version available. Please update to continue.")
                .setCancelable(false)
                .setPositiveButton("Update", (dialog, which) -> {

                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    activity.startActivity(intent);
                    activity.finish();

                })
                .show();
    }
}